<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Template__Month' );


	class Tribe_Events_Month_Template extends Tribe__Events__Template__Month {

	}