<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Template__Single_Event' );


	class Tribe_Events_Single_Event_Template extends Tribe__Events__Template__Single_Event {

	}